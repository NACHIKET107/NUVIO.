# NUVIO

Welcome to the NUVIO website! This site is built with basic HTML, CSS, and JavaScript.

## Features

- Light and Dark Mode
- AI Chat Assistant (UI only)
- AI Coding Assistant (UI only)
- Image Generator (UI only)

## How to Run

Open `index.html` in your browser.

## Deploy to Netlify

1. Drag and drop the folder to Netlify.
2. Or connect your GitHub repo and enable auto-deploy.
